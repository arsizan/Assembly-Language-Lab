# kit.ps1 - build an MDA-8086 program and run it on the kit over the serial port.
# Works on Windows 10/11 with the built-in Windows PowerShell; no install needed.
#   KIT.bat                -> pick a program from this folder
#   KIT.bat K28.ASM        -> assemble K28.ASM -> K28.ABS (+ K28.LST), load it and run it
#   KIT.bat K28.ABS        -> load and run an existing .ABS file
#   KIT.bat K28.ASM -NoRun -> build and load only;  -NoSend -> only make the .ABS
# Dragging a file onto KIT.bat does the same as typing its name.
# Assembler: jwasm.exe (MASM 5.1 mode, -Zm) in this folder. Its output was checked
# byte-for-byte against the lab's TASM + LINK + MEXE2ABS on the lab's sample programs.
param(
    [string]$File = '',
    [string]$Port = '',
    [switch]$NoRun,
    [switch]$NoSend
)

$ErrorActionPreference = 'Stop'
$here = Split-Path -Parent $MyInvocation.MyCommand.Path
$logFile = Join-Path $here 'kit_log.txt'

function Log([string]$s) { try { [IO.File]::AppendAllText($logFile, $s) } catch { } }

function Say([string]$s, [string]$color = 'White') {
    Write-Host $s -ForegroundColor $color
    Log ($s + "`r`n")
}

# print text coming from the kit
function Show([string]$s) {
    if ($s) {
        $s = $s.Replace([string][char]0, '').Replace([string][char]7, '')
        $s = $s.Replace("`r`n", "`n").Replace("`r", "`n")
        Write-Host $s -NoNewline -ForegroundColor Cyan
        Log ($s.Replace("`n", "`r`n"))
    }
}

Log ("`r`n===== " + (Get-Date -Format 'yyyy-MM-dd HH:mm:ss') + " =====`r`n")
trap { Log ('ERROR: ' + ($_ | Out-String)); break }

# read and print whatever the kit sends during $ms milliseconds
function Read-For($sp, [int]$ms) {
    $sw = [Diagnostics.Stopwatch]::StartNew()
    $all = ''
    while ($sw.ElapsedMilliseconds -lt $ms) {
        $t = $sp.ReadExisting()
        if ($t) { $all += $t; Show $t }
        Start-Sleep -Milliseconds 20
    }
    return $all
}

# send text slowly (2 ms per character) so the kit never misses a character
function Send-Slow($sp, [string]$s) {
    $sw = New-Object Diagnostics.Stopwatch
    foreach ($ch in $s.ToCharArray()) {
        $sp.Write([string]$ch)
        $sw.Restart()
        while ($sw.Elapsed.TotalMilliseconds -lt 2.0) { }
    }
}

function Open-Port([string]$name) {
    $sp = New-Object System.IO.Ports.SerialPort($name, 9600, [System.IO.Ports.Parity]::None, 8, [System.IO.Ports.StopBits]::One)
    $sp.Handshake = [System.IO.Ports.Handshake]::None
    $sp.DtrEnable = $true
    $sp.RtsEnable = $true
    $sp.ReadTimeout = 500
    $sp.WriteTimeout = 5000
    $sp.Open()
    return $sp
}

# send Enter and see if the kit answers with its "8086 >" prompt
function Test-Kit($sp) {
    $sp.DiscardInBuffer()
    $sp.Write("`r")
    $got = ''
    $sw = [Diagnostics.Stopwatch]::StartNew()
    while ($sw.ElapsedMilliseconds -lt 800) {
        $got += $sp.ReadExisting()
        if ($got -match '8086|>') { return $true }
        Start-Sleep -Milliseconds 30
    }
    return $false
}

# EXE made by the assembler -> .ABS (Intel HEX from offset 1000H, 32 bytes per line),
# the same layout as the lab's MEXE2ABS.EXE writes. Returns the number of code bytes.
function Convert-ExeToAbs([string]$exePath, [string]$absPath) {
    $d = [IO.File]::ReadAllBytes($exePath)
    if ($d.Length -lt 32 -or $d[0] -ne 0x4D -or $d[1] -ne 0x5A) { throw 'The assembler did not make a valid EXE file.' }
    $last  = [int][BitConverter]::ToUInt16($d, 2)
    $pages = [int][BitConverter]::ToUInt16($d, 4)
    $hpar  = [int][BitConverter]::ToUInt16($d, 8)
    $size = $pages * 512
    if ($last -ne 0) { $size = $size - 512 + $last }
    if ($size -gt $d.Length) { $size = $d.Length }
    $start = $hpar * 16
    $org = $start + 0x1000
    for ($i = $start; $i -lt [Math]::Min($org, $size); $i++) {
        if ($d[$i] -ne 0) { throw 'Code or data found below 1000H. Put CODE SEGMENT first and ORG 1000H before the first instruction.' }
    }
    if ($size -le $org) { throw 'No code at 1000H. Put ORG 1000H before the first instruction.' }
    $count = $size - $org
    $sb = New-Object Text.StringBuilder
    for ($off = 0; $off -lt $count; $off += 32) {
        $n = [Math]::Min(32, $count - $off)
        $addr = 0x1000 + $off
        $rec = New-Object byte[] ($n + 4)
        $rec[0] = $n
        $rec[1] = ($addr -shr 8) -band 0xFF
        $rec[2] = $addr -band 0xFF
        $rec[3] = 0
        [Array]::Copy($d, $org + $off, $rec, 4, $n)
        $sum = 0
        foreach ($b in $rec) { $sum += $b }
        $hex = ($rec | ForEach-Object { $_.ToString('X2') }) -join ''
        [void]$sb.Append(':' + $hex + ((-$sum) -band 0xFF).ToString('X2') + "`r`n")
    }
    [void]$sb.Append(":00000001FF`r`n")
    [IO.File]::WriteAllText($absPath, $sb.ToString(), [Text.Encoding]::ASCII)
    return $count
}

# assemble X.ASM with jwasm.exe -> X.ABS next to it. Returns the .ABS path.
function Build-Asm([string]$asmPath) {
    $jw = Join-Path $here 'jwasm.exe'
    if (-not (Test-Path -LiteralPath $jw)) { Say "jwasm.exe is missing from $here" 'Red'; exit 1 }
    $dir  = Split-Path -Parent $asmPath
    $name = [IO.Path]::GetFileNameWithoutExtension($asmPath)
    $abs  = Join-Path $dir ($name + '.ABS')
    $exe  = Join-Path $env:TEMP ('kit_' + $name + '.exe')
    if (Test-Path -LiteralPath $exe) { Remove-Item -LiteralPath $exe -Force }
    Say "Assembling $name.ASM ..."
    $old = $ErrorActionPreference
    $ErrorActionPreference = 'Continue'
    Push-Location $env:TEMP          # jwasm writes its .err file into the current folder
    $out = @(& $jw -mz -Zm -nologo "-Fo$exe" "$asmPath" 2>&1 | ForEach-Object { "$_" })
    $code = $LASTEXITCODE
    Pop-Location
    $ErrorActionPreference = $old
    $nerr = 0
    foreach ($o in $out) {
        if ($o -match 'A4204') { continue }                    # "No stack defined": not needed on the kit
        if ($o -match ': \d+ lines, \d+ passes') { continue }  # summary line
        if ($o -cmatch 'Error') { Say $o 'Red'; $nerr++ }
        elseif ($o -cmatch 'Warning') { Say $o 'Yellow' }
        elseif ($o.Trim()) { Say $o 'Gray' }
    }
    if (($code -ne 0) -or -not (Test-Path -LiteralPath $exe)) {
        Say ''
        Say "Assembly failed ($nerr error(s)). The number in ( ) is the line number in $name.ASM. Fix it, save, and run again." 'Red'
        exit 1
    }
    try { $n = Convert-ExeToAbs $exe $abs }
    catch { Say $_.Exception.Message 'Red'; exit 1 }
    Remove-Item -LiteralPath $exe -Force -ErrorAction SilentlyContinue
    Say ("Made {0}.ABS ({1} bytes of code)." -f $name, $n) 'Green'
    return $abs
}

# ---------- 1. choose the program file ----------
if (-not $File) {
    $list = @(Get-ChildItem -Path $here -Filter '*.ASM' | Sort-Object Name)
    $asmNames = @($list | ForEach-Object { $_.BaseName.ToUpper() })
    $list += @(Get-ChildItem -Path $here -Filter '*.ABS' | Sort-Object Name | Where-Object { $asmNames -notcontains $_.BaseName.ToUpper() })
    if ($list.Count -eq 0) { Say "No .ASM or .ABS file in $here" 'Red'; exit 1 }
    Say "Programs in $here :"
    for ($i = 0; $i -lt $list.Count; $i++) { Say ("  {0}) {1}" -f ($i + 1), $list[$i].Name) }
    $ans = Read-Host 'Type a number and press Enter'
    $k = 0
    if (-not [int]::TryParse($ans, [ref]$k) -or $k -lt 1 -or $k -gt $list.Count) { Say 'Wrong number.' 'Red'; exit 1 }
    $File = $list[$k - 1].FullName
}
if (-not (Test-Path -LiteralPath $File)) { Say "File not found: $File" 'Red'; exit 1 }
$File = (Resolve-Path -LiteralPath $File).Path
$ext = [IO.Path]::GetExtension($File).ToUpper()
if ($ext -eq '.ASM') { $File = Build-Asm $File }
elseif ($ext -ne '.ABS') { Say 'Give an .ASM or .ABS file.' 'Red'; exit 1 }
if ($NoSend) { Say 'Done (not sent to the kit).' 'Green'; exit 0 }

# ---------- 2. read and check the Intel HEX records ----------
$text = [IO.File]::ReadAllText($File).Replace([string][char]26, '')
$lines = @($text -split "`n" | ForEach-Object { $_.Trim() } | Where-Object { $_ -match '^:[0-9A-Fa-f]+$' })
$nbytes = 0
$hasEnd = $false
foreach ($l in $lines) {
    if ((($l.Length - 1) % 2) -ne 0) { Say "Broken line in file: $l" 'Red'; exit 1 }
    $sum = 0
    $raw = @()
    for ($j = 1; $j -lt $l.Length; $j += 2) { $raw += [Convert]::ToByte($l.Substring($j, 2), 16) }
    foreach ($b in $raw) { $sum += $b }
    if (($sum -band 0xFF) -ne 0) { Say "Checksum error in line: $l" 'Red'; exit 1 }
    if ($raw[3] -eq 0) { $nbytes += $raw[0] }
    if ($raw[3] -eq 1) { $hasEnd = $true }
}
if (-not $hasEnd) { $lines += ':00000001FF' }
Say ("File: {0}  ({1} bytes of code, {2} records)" -f [IO.Path]::GetFileName($File), $nbytes, $lines.Count) 'Green'

# ---------- 3. find the kit ----------
$names = @()
if ($Port) { $names = @($Port.ToUpper()) } else { $names = @([System.IO.Ports.SerialPort]::GetPortNames() | Sort-Object -Unique) }
if ($names.Count -eq 0) { Say 'This PC has no COM port.' 'Red'; exit 1 }

$open = [ordered]@{}
foreach ($n in $names) {
    try { $open[$n] = Open-Port $n }
    catch { Say "  $n : cannot open (close PuTTY or any other program using it)" 'DarkYellow' }
}
if ($open.Count -eq 0) { Say 'No COM port could be opened.' 'Red'; exit 1 }

$kit = $null
$kitName = ''
try {
    foreach ($n in @($open.Keys)) {
        if (Test-Kit $open[$n]) { $kit = $open[$n]; $kitName = $n; break }
    }
    if (-not $kit) {
        Say ''
        Say 'Kit is not answering.' 'Yellow'
        Say 'On the kit: put the SELECT MODE switch to PC, then press RESET.' 'Yellow'
        Say 'Waiting up to 60 seconds ...' 'Yellow'
        $buf = @{}
        foreach ($n in @($open.Keys)) { $buf[$n] = '' }
        $sw = [Diagnostics.Stopwatch]::StartNew()
        $lastPoke = 0
        while ((-not $kit) -and ($sw.ElapsedMilliseconds -lt 60000)) {
            foreach ($n in @($open.Keys)) {
                $buf[$n] += $open[$n].ReadExisting()
                if ($buf[$n] -match '8086|>') { $kit = $open[$n]; $kitName = $n; break }
            }
            if ((-not $kit) -and ($sw.ElapsedMilliseconds - $lastPoke -gt 2000)) {
                foreach ($n in @($open.Keys)) { $open[$n].Write("`r") }
                $lastPoke = $sw.ElapsedMilliseconds
            }
            Start-Sleep -Milliseconds 100
        }
    }
    foreach ($n in @($open.Keys)) { if ($n -ne $kitName) { $open[$n].Close() } }
    if (-not $kit) {
        Say 'Still no answer from the kit. Check: power ON, SELECT MODE = PC, serial cable plugged in, then press RESET and run this again.' 'Red'
        exit 1
    }
    Say "Kit found on $kitName (9600 baud)." 'Green'
    Start-Sleep -Milliseconds 300
    $null = $kit.ReadExisting()

    # ---------- 4. download: L command + HEX records ----------
    Say 'Sending L (download) ...'
    $kit.Write("L`r")
    $null = Read-For $kit 700
    foreach ($l in $lines) {
        Send-Slow $kit ($l + "`r`n")
        $null = Read-For $kit 40
    }
    $null = Read-For $kit 1200
    Say ''
    Say 'Download finished.' 'Green'

    # ---------- 5. run: G 0000:1000 ----------
    if (-not $NoRun) {
        Say 'Starting the program: G 0000:1000'
        Send-Slow $kit "G 0000:1000`r"
        $null = Read-For $kit 800
        Say ''
        Say 'Program is running on the kit. Press RESET on the kit to stop it.' 'Green'
    }
}
finally {
    foreach ($n in @($open.Keys)) { try { $open[$n].Close() } catch { } }
}
