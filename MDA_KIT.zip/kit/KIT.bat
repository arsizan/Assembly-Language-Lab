@echo off
title MDA-8086 kit loader
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0kit.ps1" %*
echo.
pause
